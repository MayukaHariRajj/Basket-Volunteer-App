package com.example.basket;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ResetPasswrod extends AppCompatActivity {
    
    private EditText emailEditText;
    private Button resetPasswordButton;
    FirebaseAuth fAuth;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_passwrod);
        
        emailEditText = (EditText) findViewById(R.id.email1);
        resetPasswordButton = (Button) findViewById(R.id.resetPasswordLocal);
        fAuth = FirebaseAuth.getInstance();


        resetPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetPassword();
            }
        });
    }

    private void resetPassword() {
        String email1 = emailEditText.getText().toString().trim();

        if (email1.isEmpty()){
            emailEditText.setError("Email is required!");
            emailEditText.requestFocus();
            return;
        }
        if (Patterns.EMAIL_ADDRESS.matcher(email1).matches()){
            emailEditText.setError("Please provide valid email");
            emailEditText.requestFocus();
            return;
        }
        fAuth.sendPasswordResetEmail(email1).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()) {
                    Toast.makeText(ResetPasswrod.this, "Check you rmail to reset your password!", Toast.LENGTH_LONG).show();

                }else{
                    Toast.makeText(ResetPasswrod.this, "Try Again!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}