package com.example.basket;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

class AA_RecyclerViewAdapter extends RecyclerView.Adapter<AA_RecyclerViewAdapter.MyViewHolder> {
    Context context;
    ArrayList<AminoAcidModel> aminoAcidModels;


    public AA_RecyclerViewAdapter(Context context, ArrayList<AminoAcidModel> aminoAcidModels){
        this.context = context;
        this.aminoAcidModels = aminoAcidModels;

    }

    @NonNull
    @Override
    public AA_RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_view_row,parent, false);
        return new AA_RecyclerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AA_RecyclerViewAdapter.MyViewHolder holder, int position) {

        holder.tvName.setText(aminoAcidModels.get(position).getAminoAcidName());
        holder.tv3Letter.setText(aminoAcidModels.get(position).getAminoAcidAbbreviation());
        holder.imageView1.setImageResource(aminoAcidModels.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return aminoAcidModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView1;
        TextView tvName, tv3Letter;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView1 = itemView.findViewById(R.id.imageView12);
            tvName = itemView.findViewById(R.id.textView15);
            tv3Letter = itemView.findViewById(R.id.textView16);

        }
    }

}
