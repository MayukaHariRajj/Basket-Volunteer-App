package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class ParticipatingPosts extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageView btMenu;
    RecyclerView recyclerView;
    private RecyclerView recyclerView2;
    private ProductsAdapter adapter;
    private List<Product> productList;
    private ProgressBar progressBar;


    private FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participating_posts);

        drawerLayout = findViewById(R.id.drawer_layout);
        btMenu = findViewById(R.id.bt_menu);
        recyclerView = findViewById(R.id.recycler_view);

            progressBar = findViewById(R.id.progressbar);

            recyclerView2 = findViewById(R.id.recyclerview_products);
            recyclerView2.setHasFixedSize(true);
            recyclerView2.setLayoutManager(new LinearLayoutManager(this));

            productList = new ArrayList<>();
            adapter = new ProductsAdapter(this, productList);
            recyclerView2.setAdapter(adapter);
            db = FirebaseFirestore.getInstance();


            db.collection("Event Entries").get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                            progressBar.setVisibility(View.GONE);

                            if(!queryDocumentSnapshots.isEmpty()){

                                List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                                for(DocumentSnapshot d : list){

                                    Product p = d.toObject(Product.class);
                                    p.setId(d.getId());
                                    productList.add(p);

                                }

                                adapter.notifyDataSetChanged();

                            }


                        }
                    });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MainAdapter(this, MainActivity2.arrayList));

        btMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        MainActivity2.closeDrawer(drawerLayout);

    }
}