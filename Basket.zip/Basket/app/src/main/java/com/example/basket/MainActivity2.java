package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Paint;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageView btMenu, btSearch;
    RecyclerView recyclerView ;
    ImageView addpost;
    Button button;

    static ArrayList<String> arrayList = new ArrayList<>();
    MainAdapter adapter;

    public static void closeDrawer(DrawerLayout drawerLayout) {

        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        addpost = findViewById(R.id.addpost);
        addpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, PostPage.class);
                startActivity(intent);
            }
        });


        drawerLayout = findViewById(R.id.drawer_layout);
        btMenu = findViewById(R.id.bt_menu);
        btSearch = findViewById(R.id.search);
        recyclerView = findViewById(R.id.recycler_view);

        ListView listView = findViewById(R.id.listview);

        List<String> list = new ArrayList<>();
        list.add("ALL EVENTS");
        list.add("FLOOD RELIEF");
        list.add("ENVIRONMENTAL");
        list.add("GENERAL ASSISTANCE");
        list.add("FOOD BASED");
        list.add("CLEAN UP");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(position==0){
                    startActivity(new Intent(MainActivity2.this, MainActivity3.class));
                }else if(position==1){
                    startActivity(new Intent(MainActivity2.this,Floodrelief.class));
                }else if(position==2) {
                    startActivity(new Intent(MainActivity2.this, Environmental.class));
                }else if(position==3)  {
                    startActivity(new Intent(MainActivity2.this, GeneralAssistance.class));
                }else if(position==4)  {
                    startActivity(new Intent(MainActivity2.this, FoodBased.class));
                }else if(position==5)  {
                    startActivity(new Intent(MainActivity2.this, Environmental.class));
                }
            }
        });

        arrayList.clear();

        arrayList.add("Home");
        arrayList.add("My Profile");
        arrayList.add("My Messages");
        arrayList.add("My Posted Events");
        arrayList.add("My Participating Events");
        arrayList.add("Customer Support");
        arrayList.add("Log Out");
        adapter = new MainAdapter(this,arrayList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btMenu.setOnClickListener(view -> drawerLayout.openDrawer(GravityCompat.START));


        }

    @Override
    protected void onPause() {
        super.onPause();
        closeDrawer(drawerLayout);

    }
}

