package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.rpc.Help;

import java.util.LinkedList;
import java.util.List;

public class MainActivity5 extends AppCompatActivity {

    String []data = {"Simply Giving", "River Clean Up", "Great Heart"};
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        Button button = findViewById(R.id.ADD);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Event joined successfully", Toast.LENGTH_LONG).show();
            }
        });


        List<String> items = new LinkedList<>();
        items.add("River Clean Up");
        items.add("Simply Giving");
        items.add("Great Heart");

        RecyclerView recyclerView = findViewById(R.id.recyclerView5);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        DemoAdapter adapter = new DemoAdapter(items);

        recyclerView.setAdapter(adapter);

        findViewById(R.id.ADD).setOnClickListener(view -> {
            items.add(data[counter%3]);
            counter++;
            adapter.notifyItemInserted(items.size()-1);
        });
    }
}