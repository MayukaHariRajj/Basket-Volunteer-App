package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class GeneralAssistance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_assistance);
        ListView listView = findViewById(R.id.listview4);

        List<String> list = new ArrayList<>();

        list.add("SIMPLY GIVING MALAYSIA");
        list.add("GREAT HEART");
        list.add("MALAYSIAN RED CRESCENT SOCIETY");
        list.add("MALAYSIAN RELIEF AGENCY");
        list.add("THE HOPE BRANCH");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(position==0){
                    startActivity(new Intent(GeneralAssistance.this,EventDetailsPage.class));
                }else if(position==1){
                    startActivity(new Intent(GeneralAssistance.this,GreatHeart.class));
                }
            }
        });




    }
}
