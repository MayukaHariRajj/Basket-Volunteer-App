package com.example.basket;

import com.google.firebase.database.Exclude;

import java.io.Serializable;

public class Employee implements Serializable {

    @Exclude
    private String key;
    private String date, time, location, help, details;
    public Employee(

    ){

    }
    public Employee(String date, String time, String location, String help, String details) {
        this.date = date;
        this.time = time;
        this.location = location;
        this.help = help;
        this.details = details;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getHelp() {
        return help;
    }

    public void setHelp(String help) {
        this.help = help;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getKey()
    {
        return key;
    }

    public void setKey(String key)
    {
        this.key = key;
    }
}