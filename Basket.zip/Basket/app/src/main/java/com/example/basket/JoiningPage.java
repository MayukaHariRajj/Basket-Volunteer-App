package com.example.basket;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class JoiningPage extends AppCompatActivity implements View.OnClickListener {
    private EditText editTextName;
    private EditText editTextBrand;
    private EditText editTextDesc;
    private EditText editTextPrice;
    private EditText editTextQty;

    private FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joining_page);
        db = FirebaseFirestore.getInstance();

        editTextName = findViewById(R.id.edittext_name);
        editTextBrand = findViewById(R.id.edittext_brand);
        editTextDesc = findViewById(R.id.edittext_desc);
        editTextPrice = findViewById(R.id.edittext_price);
        editTextQty = findViewById(R.id.edittext_qty);

        findViewById(R.id.button_save).setOnClickListener(this);
        findViewById(R.id.textview_view_products).setOnClickListener(this);
    }

    private boolean hasValidationErrors(String eventname, String fullname, String phone, String age, String ic) {
        if (eventname.isEmpty()) {
            editTextName.setError("Event Name is required");
            editTextName.requestFocus();
            return true;
        }

        if (fullname.isEmpty()) {
            editTextBrand.setError("Full Name is required");
            editTextBrand.requestFocus();
            return true;
        }

        if (phone.isEmpty()) {
            editTextDesc.setError("Phone number is required");
            editTextDesc.requestFocus();
            return true;
        }

        if (age.isEmpty()) {
            editTextPrice.setError("Your age is required");
            editTextPrice.requestFocus();
            return true;
        }

        if (ic.isEmpty()) {
            editTextQty.setError("Your IC required");
            editTextQty.requestFocus();
            return true;
        }
        return false;
    }


    private void saveProduct(){
        String eventname = editTextName.getText().toString().trim();
        String fullname = editTextBrand.getText().toString().trim();
        String phone = editTextDesc.getText().toString().trim();
        String age = editTextPrice.getText().toString().trim();
        String ic = editTextQty.getText().toString().trim();

        if (!hasValidationErrors(eventname, fullname, phone, age, ic )) {
            CollectionReference dbProducts = db.collection("Event Entries");

            Product product = new Product(
                    eventname,
                    fullname,
                    phone,
                    Double.parseDouble(age),
                    Integer.parseInt(ic)
            );

            dbProducts.add(product)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Toast.makeText(JoiningPage.this, "Joined Event Successfully", Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(JoiningPage.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        }
    }

            @Override
            public void onClick(View v) {

                switch(v.getId()){
                    case R.id.button_save:
                        saveProduct();
                        break;
                    case R.id.textview_view_products:
                        startActivity(new Intent(this, ParticipatingPosts.class));
                        break;
                }

            }
        }