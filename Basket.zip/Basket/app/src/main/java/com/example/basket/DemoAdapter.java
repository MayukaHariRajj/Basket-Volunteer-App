package com.example.basket;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DemoAdapter extends  RecyclerView.Adapter<Add>{

    List<String> items;

    public DemoAdapter(List<String> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public Add onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);

        return new Add(view).linkAdapter(this);
    }

    @Override
    public void onBindViewHolder(@NonNull Add holder, int position) {

        holder.textView.setText(items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}

class Add extends RecyclerView.ViewHolder{
    TextView textView;
    private DemoAdapter adapter;

    public Add(@NonNull View itemView){
        super(itemView);

        textView = itemView.findViewById(R.id.TEXT);
        itemView.findViewById(R.id.Delete).setOnClickListener(view -> {
            adapter.items.remove(getAdapterPosition());
            adapter.notifyItemChanged(getAdapterPosition());
        });
    }

    public Add linkAdapter(DemoAdapter adapter){
        this.adapter = adapter;
        return this;
    }

}
