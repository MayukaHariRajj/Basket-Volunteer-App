package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Environmental extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_environmental);

        ListView listView = findViewById(R.id.listview3);

        List<String> list = new ArrayList<>();

        list.add("RIVER CLEAN UP");
        list.add("SIMPLY GIVING MALAYSIA");
        list.add("GLOBAL ENVIRONMENTAL CENTER");
        list.add("KARUN HIJAU");
        list.add("MALAYSIAN ECO-BRICKERS");
        list.add("FRIENDS OF KLANG VALLEY BASIN");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if(position==0){
                    startActivity(new Intent(Environmental.this, Rivercleanup.class));
                }else if(position==1){
                    startActivity(new Intent(Environmental.this,EventDetailsPage.class));
                }
            }
        });




    }
}