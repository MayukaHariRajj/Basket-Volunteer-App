package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {

    Button button;

    ArrayList<AminoAcidModel> aminoAcidModels = new ArrayList<>();

    int[] aminoAcidImages = {R.drawable.charityright,R.drawable.simplygiving,
            R.drawable.yayasan, R.drawable.mercy, R.drawable.greatheart,
            R.drawable.global, R.drawable.simplygiving2};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        RecyclerView recyclerView = findViewById(R.id.mRecyclerView);

        setUpAminoAcidModels();
        AA_RecyclerViewAdapter adapter = new AA_RecyclerViewAdapter(this, aminoAcidModels);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    private void setUpAminoAcidModels(){
        String[] aminoAcidName = getResources().getStringArray(R.array.amino_acids_full_txt);
        String[] aminoAcidAbbreviation = getResources().getStringArray(R.array.amino_acids_three_letter_txt);

        for (int i = 0; i<aminoAcidName.length; i++){
            aminoAcidModels.add(new AminoAcidModel(aminoAcidName[i],
                    aminoAcidAbbreviation[i],aminoAcidImages[i]));
        }

    }

        }
