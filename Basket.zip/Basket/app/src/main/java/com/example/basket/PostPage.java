package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class PostPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_page);

        final EditText edit_time = findViewById(R.id.edit_time);
        final EditText edit_date = findViewById(R.id.edit_date);
        final EditText edit_location = findViewById(R.id.edit_location);
        final EditText edit_help = findViewById(R.id.edit_help);
        final EditText edit_details = findViewById(R.id.edit_details);

        Button btn = findViewById(R.id.btn_submit);
        Button btn_open = findViewById(R.id.btn_open);
        btn_open.setOnClickListener(v->
        {
            Intent intent =new Intent(PostPage.this, MyPosts.class);
            startActivity(intent);
        });

        DAOEmployee dao =new DAOEmployee();
        Employee emp_edit = (Employee)getIntent().getSerializableExtra("EDIT");
        if(emp_edit !=null)
        {
            btn.setText("UPDATE");
            edit_date.setText(emp_edit.getDate());
            edit_time.setText(emp_edit.getTime());
            edit_location.setText(emp_edit.getLocation());
            edit_help.setText(emp_edit.getHelp());
            edit_details.setText(emp_edit.getDetails());
            btn_open.setVisibility(View.GONE);
        }
        else
        {
            btn.setText("SUBMIT");
            btn_open.setVisibility(View.VISIBLE);
        }
        btn.setOnClickListener(v->
        {

            Employee emp = new Employee(edit_date.getText().toString(),
                    edit_time.getText().toString(),
                    edit_location.getText().toString(),
                    edit_help.getText().toString(),
                    edit_details.getText().toString());
            if(emp_edit==null)
            {
                dao.add(emp).addOnSuccessListener(suc ->
                {
                    Toast.makeText(this, "Posted Successfully", Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(er ->
                {
                    Toast.makeText(this, "" + er.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
            else
            {
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("date", edit_date.getText().toString());
                hashMap.put("time", edit_time.getText().toString());
                hashMap.put("location", edit_location.getText().toString());
                hashMap.put("help", edit_help.getText().toString());
                hashMap.put("details", edit_details.getText().toString());

                dao.update(emp_edit.getKey(), hashMap).addOnSuccessListener(suc ->
                {
                    Toast.makeText(this, "Post has been updated", Toast.LENGTH_SHORT).show();
                    finish();
                }).addOnFailureListener(er ->
                {
                    Toast.makeText(this, "" + er.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        });


    }
}