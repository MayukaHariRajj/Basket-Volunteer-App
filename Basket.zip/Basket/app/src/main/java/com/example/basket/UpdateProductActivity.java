package com.example.basket;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

public class UpdateProductActivity extends AppCompatActivity  implements View.OnClickListener {

    private EditText editTextName;
    private EditText editTextBrand;
    private EditText editTextDesc;
    private EditText editTextPrice;
    private EditText editTextQty;
    private FirebaseFirestore db;
    private Product product;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);

        product = (Product) getIntent().getSerializableExtra("Event Entries");
        db = FirebaseFirestore.getInstance();

        editTextName = findViewById(R.id.edittext_name);
        editTextBrand = findViewById(R.id.edittext_brand);
        editTextDesc = findViewById(R.id.edittext_desc);
        editTextPrice = findViewById(R.id.edittext_price);
        editTextQty = findViewById(R.id.edittext_qty);

        editTextName.setText(product.getEventname());
        editTextBrand.setText(product.getFullname());
        editTextDesc.setText(product.getPhone());
        editTextPrice.setText(String.valueOf(product.getAge()));
        editTextQty.setText(String.valueOf(product.getIc()));


        findViewById(R.id.button_update).setOnClickListener(this);
        findViewById(R.id.button_delete).setOnClickListener(this);
    }

    private boolean hasValidationErrors(String eventname, String fullname, String phone, String age, String ic) {
        if (eventname.isEmpty()) {
            editTextName.setError("Event Name required");
            editTextName.requestFocus();
            return true;
        }

        if (fullname.isEmpty()) {
            editTextBrand.setError("Full name required");
            editTextBrand.requestFocus();
            return true;
        }

        if (phone.isEmpty()) {
            editTextDesc.setError("Phone number required");
            editTextDesc.requestFocus();
            return true;
        }

        if (age.isEmpty()) {
            editTextPrice.setError("Age required");
            editTextPrice.requestFocus();
            return true;
        }

        if (ic.isEmpty()) {
            editTextQty.setError("IC number required");
            editTextQty.requestFocus();
            return true;
        }
        return false;
    }


    private void updateProduct() {
        String eventname = editTextName.getText().toString().trim();
        String fullname = editTextBrand.getText().toString().trim();
        String phone = editTextDesc.getText().toString().trim();
        String age = editTextPrice.getText().toString().trim();
        String ic = editTextQty.getText().toString().trim();

        if (!hasValidationErrors(eventname, fullname, phone, age, ic)) {

            Product p = new Product(
                    eventname, fullname, phone,
                    Double.parseDouble(age),
                    Integer.parseInt(ic)
            );


            db.collection("Event Entries").document(product.getId())
                    .set(p)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(UpdateProductActivity.this, "Details Updated", Toast.LENGTH_LONG).show();
                        }
                    });
        }
    }

    private void deleteProduct() {
        db.collection("Event Entries").document(product.getId()).delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(UpdateProductActivity.this, "Event has been deleted", Toast.LENGTH_LONG).show();
                            finish();
                            startActivity(new Intent(UpdateProductActivity.this, ParticipatingPosts.class));
                        }
                    }
                });
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_update:
                updateProduct();
                break;
            case R.id.button_delete:

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Are you sure you want to delete?");
                builder.setMessage("You can't undo this action");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteProduct();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog ad = builder.create();
                ad.show();

                break;
        }
    }
}