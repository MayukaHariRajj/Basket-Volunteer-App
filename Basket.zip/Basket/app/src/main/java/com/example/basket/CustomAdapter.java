package com.example.basket;

public class CustomAdapter {
}
