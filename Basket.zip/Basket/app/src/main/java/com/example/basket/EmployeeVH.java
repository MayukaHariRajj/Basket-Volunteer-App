package com.example.basket;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EmployeeVH extends RecyclerView.ViewHolder {
    public TextView txt_date, txt_time, txt_location, txt_help, txt_details, txt_option;

    public EmployeeVH(@NonNull View itemView)
    {
        super(itemView);
        txt_date = itemView.findViewById(R.id.txt_date);
        txt_time = itemView.findViewById(R.id.txt_time);
        txt_location = itemView.findViewById(R.id.txt_location);
        txt_help = itemView.findViewById(R.id.txt_help);
        txt_details = itemView.findViewById(R.id.txt_details);
        txt_option = itemView.findViewById(R.id.txt_option);
    }
}