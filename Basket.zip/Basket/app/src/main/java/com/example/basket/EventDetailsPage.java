package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.LinkedList;
import java.util.List;

public class EventDetailsPage extends AppCompatActivity {
    String []data = {"Simply Giving", "River Clean Up", "Great Heart"};
    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details_page);

        Button joinbtn = findViewById(R.id.joinbtn);
        joinbtn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(),JoiningPage.class);
            startActivity(intent);
        });

            Button location = findViewById(R.id.location);
            location.setOnClickListener(view2 -> {
                Intent intent2 = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(intent2);
            });
                Button contactbtn = findViewById(R.id.contactbtn);
                contactbtn.setOnClickListener(view1 -> {
                    Intent intent1 = new Intent(getApplicationContext(), Message.class);
                    startActivity(intent1);
            });

    }

}