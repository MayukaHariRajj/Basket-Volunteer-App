package com.example.basket;

class AminoAcidModel {
    String aminoAcidName;
    String aminoAcidAbbreviation;
    int image;

    public AminoAcidModel(String aminoAcidName, String aminoAcidAbbreviation, int image) {
        this.aminoAcidName = aminoAcidName;
        this.aminoAcidAbbreviation = aminoAcidAbbreviation;
        this.image = image;
    }

    public String getAminoAcidName() {
        return aminoAcidName;
    }

    public String getAminoAcidAbbreviation() {
        return aminoAcidAbbreviation;
    }

    public int getImage() {
        return image;
    }

}
