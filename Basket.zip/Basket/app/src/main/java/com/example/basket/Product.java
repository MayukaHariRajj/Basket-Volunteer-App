package com.example.basket;

import com.google.firebase.database.Exclude;

import java.io.Serializable;

public class Product implements Serializable {

    @Exclude
    private String id;

    private String eventname, fullname, phone;
    private double age;
    private int ic;

    public Product() {

    }

    public Product(String eventname, String fullname, String phone, double age, int ic) {
        this.eventname = eventname;
        this.fullname = fullname;
        this.phone = phone;
        this.age = age;
        this.ic = ic;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEventname() {
        return eventname;
    }

    public String getFullname() {
        return fullname;
    }

    public String getPhone() {
        return phone;
    }

    public double getAge() {
        return age;
    }

    public int getIc() {
        return ic;
    }
}
