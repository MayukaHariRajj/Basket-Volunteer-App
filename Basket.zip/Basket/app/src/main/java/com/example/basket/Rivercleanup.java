package com.example.basket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class Rivercleanup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rivercleanup);
        Button joinbtn = findViewById(R.id.joinbtn);
        joinbtn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(),JoiningPage.class);
            startActivity(intent);
        });
            Button location = findViewById(R.id.location);
            location.setOnClickListener(view2 -> {
                Intent intent2 = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(intent2);

                Button contactbtn = findViewById(R.id.contactbtn);
                contactbtn.setOnClickListener(view1 -> {
                    Intent intent1 = new Intent(getApplicationContext(), Message.class);
                    startActivity(intent1);
                });
            });

    }

}